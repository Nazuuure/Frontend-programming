import type { Slide } from '../types';
import styles from './Workspace.module.css'

type WorkspaceProps = {
  slide: Slide;
};

function Workspace({ slide }: WorkspaceProps) {
    return (
        <div className={styles.workspace}>
            <div className={styles.current_slide}>
                {slide.id}
            </div>    
        </div>
    );
}

export default Workspace;