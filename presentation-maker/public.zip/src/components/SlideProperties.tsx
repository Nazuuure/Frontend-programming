import styles from './SlideProperties.module.css'
import Button from './Button';
import { setSlideBackgroundColor, type Slide } from '../types'

interface SlidePropertiesProps {
    slide: Slide;
    onSlide: (slide: Slide)=>void;
}


function SlideProperties({ slide, onSlide }: SlidePropertiesProps) {
  if (!slide) {
    return <div className={styles.properties_container}>Слайд не выбран</div>;
  }

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newColor = e.target.value;
    slide = setSlideBackgroundColor(slide, e.target.value)
    onSlide(slide)
  };

  const currentBgColor = slide.background?.type === 'color' ? slide.background.color : '#ffffff';

  return (
    <div className={styles.properties_container}>
      <div className={styles.picker_wrapper}>
        <label htmlFor="slide-color-picker" className={styles.picker_label}>
          <Button onClick={() => {}}>COLOR</Button>
          <span 
            className={styles.color_indicator} 
            style={{ backgroundColor: currentBgColor }}
          />
        </label>
        <input
          id="slide-color-picker"
          type="color"
          value={currentBgColor}
          onChange={handleColorChange}
          className={styles.hidden_color_input}
        />
      </div>
    </div>
  );
}


export default SlideProperties;