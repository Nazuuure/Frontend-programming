import type { Presentation, Slide } from '../types.js';
import Button from './Button.js'
import styles from './Toolbar.module.css';
import SlideProperties from './SlideProperties.js';
import { useState } from 'react';
type ToolBarProps = {
    presentation: Presentation;
    currentSlideId: string;
    onAddSlide: ()=>void;
    onPreview: ()=>void;
    onDeleteSlide: ()=>void;
}

function ToolBar({ presentation, onAddSlide, onPreview, onDeleteSlide, currentSlideId }: ToolBarProps) {
  const [slide, setSlide] = useState<Slide>(presentation.slides[presentation.slides.findIndex( (slide) => slide.id === currentSlideId )])
  const handleSetSlide = (slide: Slide) => {
    setSlide(slide)
  }
  if (!slide) return;
  return (
      <div className={styles.header}>
        <h2 className={styles.presentation_name}>{presentation.name}</h2>
        <div className={styles.toolbar}>
          <Button onClick={() => onPreview()}>PREVIEW</Button>
          <Button onClick={() => onAddSlide()}>ADD</Button>
          <Button onClick={() => onDeleteSlide()}>DELETE</Button>
          <SlideProperties slide={slide} onSlide={handleSetSlide}/>
        </div> 
      </div>
  );
}

export default ToolBar;