import type { Presentation, Slide } from './types.js';
import { useState } from 'react';
import Toolbar from './components/Toolbar.js';
import SlideList from './components/SlideList.js';
import Workspace from './components/Workspace.js';
import PreviewOverlay from './components/PreviewOverlay.js';
import styles from './App.module.css';
import { addSlide, removeSlides } from './types.js';

interface AppProps {
  initialPresentation: Presentation;
}

function App({ initialPresentation }: AppProps) {
  const [presentation, setPresentation ] = useState(initialPresentation)
  const [selectedSlideId, setSelectedSlideId] = useState<string>(presentation.slides[0]?.id ?? undefined);
  const [previewMode, setPreviewMode] = useState(false);

  if (previewMode) {
    return (
      <PreviewOverlay
        presentation={presentation}
        onClose={() => setPreviewMode(false)}
      />
    );
  }

  const handleAddSlide = () => {
    const updatedPresentation = addSlide(presentation);
    setSelectedSlideId(updatedPresentation.slides[updatedPresentation.slides.length - 1]?.id ?? undefined);
    setPresentation(updatedPresentation)
  };
  const handleSetPreviewMode = () => {
    setPreviewMode(true)
  };
  const handleDeleteSlide = () => {
    if (!selectedSlideId) return;
    const deletingIndex = presentation.slides.findIndex((slide) => slide.id === selectedSlideId);

    const updatedPresentation = removeSlides(presentation, [selectedSlideId]);
    setSelectedSlideId(presentation.slides[deletingIndex - 1].id)
    setPresentation(updatedPresentation)
  }

  const selectedSlide = presentation.slides.find((slide) => slide.id === selectedSlideId) ?? presentation.slides[0] ?? null;

  return (
    <div className={styles.appContainer}>
      <Toolbar
        presentation={presentation}
        onAddSlide={handleAddSlide} 
        onPreview={handleSetPreviewMode}
        onDeleteSlide={handleDeleteSlide}
        currentSlideId={selectedSlideId}
      />
      <div className={styles.mainArea}>
        <SlideList 
          presentation={presentation} 
          selectedSlideId={selectedSlideId ?? undefined}
          onSelectSlide={setSelectedSlideId}
        />
        {selectedSlide ? (<Workspace slide={selectedSlide} />) : (<div>Нет слайдов</div>)}
      </div>
    </div>
  );
}

export default App;
